import json
from channels.generic.websocket import WebsocketConsumer
from asgiref.sync import async_to_sync

from .api.serializers import GroupInfoSerializer, OneToOneMessageSerializer,GroupMessageSerializer


class CustomWebsocketConsumer(WebsocketConsumer):
    def connect(self):
        self.group_name = self.scope['url_route']['kwargs']['groupname']
        if self.scope['user'].is_authenticated:
            async_to_sync(self.channel_layer.group_add)(
                self.group_name,
                self.channel_name
            )
            self.accept()
        else:
            '''
                TODO : - Add custom error event.
            '''
            self.close()


    def one_to_one_message(self, data):
        serializer = OneToOneMessageSerializer(data=data)
        if serializer.is_valid():
            serializer.save()
        else:
            async_to_sync(self.channel_layer.group_send)(
                self.group_name,
                {
                    'type': 'chat.user_not_exists',  # event handler
                    'message': "Receiver not exists",
                },
            )


    def group_message(self, data):
        serializer = GroupInfoSerializer(data=data)
        if serializer.is_valid():
            instance = serializer.get_or_create()
            data['group']=instance.id
            group_serializer = GroupMessageSerializer(data=data)
            if group_serializer.is_valid():
                group_serializer.save()
            else:
                print(group_serializer.errors)
        else:
            print(serializer.errors)


    def receive(self, text_data=None, bytes_data=None):
        data = json.loads(text_data)
        data['sender'] = self.scope['user'].id
        if data['message_type'] == "ONE_TO_ONE":
            self.one_to_one_message(data)
        else:
            data['name'] = self.group_name
            data['created_by'] = self.scope['user'].id
            self.group_message(data)


    async def disconnect(self, close_code):
        async_to_sync(self.channel_layer.group_discard)(
            self.group_name,
            self.channel_name
        )
        self.close()


    def chat_user_not_exists(self, event):
        '''
            NOTE : Event handler
        '''
        self.send(text_data=json.dumps({
            "msg": "Receiver not exists",
        }))
        async_to_sync(self.channel_layer.group_discard)(
            self.group_name,
            self.channel_name
        )
        self.close()
    

    def chat_grp_not_exists(self, event):
        '''
            NOTE : Event handler
        '''
        self.send(text_data=json.dumps({
            "msg": "Grp exists",
        }))
        async_to_sync(self.channel_layer.group_discard)(
            self.group_name,
            self.channel_name
        )
        self.close()