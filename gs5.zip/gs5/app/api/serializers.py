from rest_framework import serializers
from ..models import GroupInfo, GroupMessage, OneToOneMessage, OneToOneGroup,Attachments
from user.api.serializers import UsersSerializer

class AttachmentSerializer(serializers.ModelSerializer):
    '''
    TODO : mutltiple file uploads
    '''
    file = serializers.FileField(required=False)
    group = serializers.SlugRelatedField(source='message',slug_field='id',many=True,read_only=True)
    # file = serializers.ListField(child=serializers.FileField(required=False, use_url=True ))

    class Meta():
        model = Attachments
        fields = ['id','file','group','message_type','uploaded_by','upload_date']
        extra_kwargs = {
            "uploaded_by": {'read_only': True}
        }
    
    def validate(self, validated_data):
        validated_data['uploaded_by'] = self.context['request'].user
        return validated_data

    def create(self, validated_data):
        return Attachments.objects.create(**validated_data)

 
class OneToOneGroupSerializer(serializers.ModelSerializer):
    receiver = UsersSerializer(read_only=True)

    class Meta:
        model = OneToOneGroup
        fields = ['id','receiver', 'channel_name','created_at']


class OneToOneMessageSerializer(serializers.ModelSerializer):
    class Meta:
        model = OneToOneMessage
        fields = ['id','content','sender','receiver', 'file', 'message_type','message_format', 'is_read', 'is_delete', 'created_at']

    
class GroupInfoSerializer(serializers.ModelSerializer):
    name = serializers.CharField(required=True)

    class Meta:
        model = GroupInfo
        fields = ['id','name','created_at','created_by']
    
    def get_or_create(self):
        defaults = dict(self.validated_data.copy())
        instance, _   =  GroupInfo.objects.get_or_create(name=defaults['name'],created_by=defaults['created_by'])
        return instance
        
        
class GroupMessageSerializer(serializers.ModelSerializer):
    class Meta:
        model = GroupMessage
        fields = '__all__'