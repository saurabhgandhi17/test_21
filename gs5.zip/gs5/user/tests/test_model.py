from rest_framework.test import APITestCase
from user.models import User


class TestModel(APITestCase):
    def test_create_user(self):
        user = User.objects.create_user('saurabh', 'saurabh@gmail.com', 'password@123')
        self.assertIsInstance(user, User)
        self.assertTrue(user.is_active)
        self.assertFalse(user.is_staff)
        self.assertFalse(user.is_superuser)
        self.assertEqual(user.email, 'saurabh@gmail.com')

    def test_raises_error_when_no_username_is_supplied(self):
        self.assertRaises(ValueError, User.objects.create_user, username="",email='saurabh@gmail.com', password='password@123')
        self.assertRaisesMessage(ValueError, 'The given username must be set')

    def test_raises_error_when_no_email_is_supplied(self) :
        self.assertRaises(ValueError,User.objects.create_superuser, username="saurabh",email='',password='password@123')
        
    def test_raises_error_with_message_when_no_username_is_supplied(self) :
        with self.assertRaisesMessage(ValueError,'The given username must be set') :
            User.objects.create_superuser(username='',email='saurabh@gmail.com',password='password@123')
    
    def test_raises_error_with_message_when_no_email_is_supplied(self) :
        with self.assertRaisesMessage(ValueError,'The given email must be set') :
            User.objects.create_superuser(username='saurabh',email='',password='password@123')

    def test_create_super_user(self):
        user = User.objects.create_superuser('saurabh', 'saurabh@gmail.com', 'password@123')
        self.assertIsInstance(user, User)
        self.assertTrue(user.is_active)
        self.assertTrue(user.is_staff)
        self.assertTrue(user.is_superuser)
        self.assertEqual(user.email, 'saurabh@gmail.com')
